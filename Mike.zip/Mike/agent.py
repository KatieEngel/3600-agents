from collections.abc import Callable
from time import time
from typing import List, Tuple
import math
import os

import numpy as np
import torch
import torch.nn as nn

from game import *
from game.enums import Direction, MoveType

from .trapdoor_belief import TrapdoorBelief


"""
NN-powered DivyAgent:
- Uses a trained value network (value_net.pt) as evaluation.
- Uses iterative deepening + negamax + alpha–beta pruning for search.
- Still uses TrapdoorBelief internally and encodes trapdoor info into features.
"""


class TimeoutError(Exception):
    """Raised when our per-move time budget is exceeded during search."""
    pass


# -----------------------------
# Value Network (must match training)
# -----------------------------

class ValueNet(nn.Module):
    def __init__(self, input_dim: int = 21, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Tanh(),  # output in [-1, 1]
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


# -----------------------------
# Main Agent
# -----------------------------

class PlayerAgent:
    """
    __init__ and play are the entry points for your program and should not be changed.
    You may add methods / fields as needed.
    """

    def __init__(self, board: board.Board, time_left: Callable):
        # Device for NN (CPU is totally fine here)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Load value net weights from value_net.pt in this directory
        self.value_net = ValueNet().to(self.device)
        here = os.path.dirname(__file__)
        weights_path = os.path.join(here, "value_net.pt")
        state_dict = torch.load(weights_path, map_location=self.device)
        self.value_net.load_state_dict(state_dict)
        self.value_net.eval()

        # Trapdoor belief over board (8x8)
        self.tracker = TrapdoorBelief(map_size=board.game_map.MAP_SIZE)

        # Remember our parity (even = white squares, odd = black squares)
        self.my_parity = board.chicken_player.even_chicken

        # Rough constants used in feature normalization
        self.START_TIME = 360.0
        self.START_MOVES = 40
        self.MAX_TURNS_TOTAL = 80  # 40 moves each

        # Last seen remaining time (updated in play)
        self.last_time_left = self.START_TIME

    # ------------------------------------------------------------------
    # Entry point: choose a move
    # ------------------------------------------------------------------
    def play(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        time_left: Callable,
    ):
        # Update trapdoor belief with new sensor info
        current_loc = board.chicken_player.get_location()
        self.tracker.update(current_loc, sensor_data)

        # Time budgeting
        turns_remaining = board.turns_left_player
        my_time_remaining = time_left()
        self.last_time_left = my_time_remaining  # for features

        if turns_remaining > 0:
            time_budget = (my_time_remaining / turns_remaining) - 0.05
        else:
            time_budget = my_time_remaining / 10.0
        time_budget = min(max(time_budget, 0.05), 9.0)

        start_time = time()

        # All legal moves from this position
        moves = board.get_valid_moves()
        if not moves:
            # No valid moves; engine will handle the penalty.
            # Just return some syntactically valid move.
            return (Direction.UP, MoveType.PLAIN)

        best_move = moves[0]
        current_depth = 1
        max_depth = 12

        # Iterative deepening
        while True:
            try:
                score, move = self.negamax(
                    board,
                    depth=current_depth,
                    alpha=-math.inf,
                    beta=math.inf,
                    start_time=start_time,
                    time_budget=time_budget,
                )

                if move is not None:
                    best_move = move

                current_depth += 1
                if current_depth > max_depth or (time() - start_time) > (time_budget * 0.6):
                    break

            except TimeoutError:
                # Out of time for deeper search; return best from previous depth
                break

        return best_move

    # ------------------------------------------------------------------
    # Board → feature vector (must match training order)
    # ------------------------------------------------------------------
    def board_to_features(self, board: board.Board) -> List[float]:
        """
        Build the SAME feature vector (21 floats) that the value net was trained on,
        but using the live Board object.

        Training features were:
            myx_n, myy_n,
            msx_n, msy_n,
            osx_n, osy_n,
            td1x_n, td1y_n,
            td2x_n, td2y_n,
            my_eg_n, op_eg_n, egg_diff_n,
            my_td_n, op_td_n,
            my_tm_n, op_tm_n,
            my_mv_n, op_mv_n,
            trap_trig,
            turn_frac
        """

        M = board.game_map.MAP_SIZE
        max_coord = M - 1

        # --- Positions ---
        my_x, my_y = board.chicken_player.get_location()

        # We don't know spawn positions from the engine API directly.
        # Either the engine exposes them, or we approximate them as mid-board.
        # If you later discover a proper "get_spawn" method, plug it in here.
        if hasattr(board.chicken_player, "get_spawn"):
            msx, msy = board.chicken_player.get_spawn()
        else:
            msx = max_coord / 2.0
            msy = max_coord / 2.0

        if hasattr(board.chicken_enemy, "get_spawn"):
            osx, osy = board.chicken_enemy.get_spawn()
        else:
            osx = max_coord / 2.0
            osy = max_coord / 2.0

        myx_n = my_x / max_coord
        myy_n = my_y / max_coord
        msx_n = msx / max_coord
        msy_n = msy / max_coord
        osx_n = osx / max_coord
        osy_n = osy / max_coord

        # --- Trapdoor approximation from belief ---
        # Training used ground-truth trapdoors; in live play we only know beliefs.
        # Approximate trapdoors as the most likely even + odd squares.
        even_probs = self.tracker.probs_even
        odd_probs = self.tracker.probs_odd

        td1_idx = int(even_probs.argmax())
        td1x, td1y = divmod(td1_idx, M)

        td2_idx = int(odd_probs.argmax())
        td2x, td2y = divmod(td2_idx, M)

        td1x_n = td1x / max_coord
        td1y_n = td1y / max_coord
        td2x_n = td2x / max_coord
        td2y_n = td2y / max_coord

        # --- Game stats ---
        my_eggs = board.chicken_player.get_eggs_laid()
        op_eggs = board.chicken_enemy.get_eggs_laid()
        egg_diff = my_eggs - op_eggs

        my_turds = board.chicken_player.get_turds_left()
        op_turds = board.chicken_enemy.get_turds_left()

        # We only know our own time exactly (via time_left callback).
        # Use last_time_left for our time; approximate opponent time as half.
        my_time = self.last_time_left
        op_time = self.START_TIME / 2.0

        my_moves_left = board.turns_left_player
        op_moves_left = board.turns_left_enemy

        # --- Normalization (must match training constants) ---
        my_eg_n = my_eggs / 30.0
        op_eg_n = op_eggs / 30.0
        egg_diff_n = egg_diff / 30.0

        my_td_n = my_turds / 5.0
        op_td_n = op_turds / 5.0

        my_tm_n = my_time / self.START_TIME
        op_tm_n = op_time / self.START_TIME

        my_mv_n = my_moves_left / self.START_MOVES
        op_mv_n = op_moves_left / self.START_MOVES

        # We don't track exact trapdoor-trigger events in search; set to 0.
        trap_trig = 0.0

        # Approximate global turn fraction:
        # how many total moves have been used out of 80?
        moves_used_me = self.START_MOVES - board.turns_left_player
        moves_used_op = self.START_MOVES - board.turns_left_enemy
        t_est = moves_used_me + moves_used_op
        turn_frac = t_est / self.MAX_TURNS_TOTAL

        features = [
            myx_n, myy_n,
            msx_n, msy_n,
            osx_n, osy_n,
            td1x_n, td1y_n,
            td2x_n, td2y_n,
            my_eg_n, op_eg_n, egg_diff_n,
            my_td_n, op_td_n,
            my_tm_n, op_tm_n,
            my_mv_n, op_mv_n,
            trap_trig,
            turn_frac,
        ]

        return features

    # ------------------------------------------------------------------
    # NN-based heuristic
    # ------------------------------------------------------------------
    def heuristic(self, board: board.Board) -> float:
        """
        Use the neural net to evaluate this board for the CURRENT player.
        Returns a scalar score; higher is better for the player to move.
        """
        feats = self.board_to_features(board)
        x = torch.tensor(feats, dtype=torch.float32, device=self.device).unsqueeze(0)

        with torch.no_grad():
            v = self.value_net(x).item()  # in [-1, 1]

        # Scale into a range that makes search more sensitive.
        # You can tune 200.0 up or down.
        return v * 200.0

    # ------------------------------------------------------------------
    # Negamax + alpha–beta pruning
    # ------------------------------------------------------------------
    def negamax(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        start_time: float,
        time_budget: float,
    ):
        """
        Negamax search with alpha–beta pruning.

        Returns:
            (score, best_move) where best_move is (Direction, MoveType) or None.
        """
        # Time check
        if (time() - start_time) > time_budget:
            raise TimeoutError()

        # Leaf or game over → evaluate
        if depth == 0 or board.is_game_over():
            return self.heuristic(board), None

        moves = board.get_valid_moves()
        if not moves:
            # No moves for current player is extremely bad (opponent gets 5 eggs).
            return -10000.0, None

        best_score = -math.inf
        best_move = moves[0]

        # Move ordering: Eggs > Turds > Plain
        def move_priority(m):
            m_type = m[1]
            if m_type == MoveType.EGG:
                return 3
            if m_type == MoveType.TURD:
                return 2
            return 1

        moves.sort(key=move_priority, reverse=True)

        for move in moves:
            dir_enum, type_enum = move

            # Forecast our move
            next_board = board.forecast_move(dir_enum, type_enum)
            if next_board is None:
                continue

            # Reverse perspective: now opponent becomes "player"
            next_board.reverse_perspective()

            score, _ = self.negamax(
                next_board,
                depth=depth - 1,
                alpha=-beta,
                beta=-alpha,
                start_time=start_time,
                time_budget=time_budget,
            )
            score = -score  # negamax sign flip

            if score > best_score:
                best_score = score
                best_move = move

            alpha = max(alpha, score)
            if alpha >= beta:
                break  # alpha–beta cut-off

        return best_score, best_move
