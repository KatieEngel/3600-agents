# train_value_net.py

import json
import math
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


CSV_PATH = "data-1764047780927.csv"   # adjust if needed
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# -----------------------------
# 1. Dataset & feature builder
# -----------------------------

def build_samples_from_row(row):
    """
    Given one row of the CSV (a single match), parse match_log JSON and
    return a list of (features, target_value) pairs.

    target_value is from the perspective of the player who just moved.
    """
    log = json.loads(row["match_log"])

    pos = log["pos"]                    # list of [x,y], len = turn_count
    a_eggs = log["a_eggs_laid"]
    b_eggs = log["b_eggs_laid"]
    a_turds = log["a_turds_left"]
    b_turds = log["b_turds_left"]
    a_time = log["a_time_left"]
    b_time = log["b_time_left"]
    a_moves_left = log["a_moves_left"]
    b_moves_left = log["b_moves_left"]
    trapdoor_triggered = log["trapdoor_triggered"]
    left_behind = log["left_behind"]  # we won't use this yet, but you could
    trapdoors = log["trapdoors"]      # [[x1,y1], [x2,y2]]
    spawn_a = log["spawn_a"]          # [x,y]
    spawn_b = log["spawn_b"]

    turn_count = log.get("turn_count", len(pos))
    start_time = log.get("start_time", 360.0)

    # Final eggs for each player (for target)
    final_a_eggs = a_eggs[-1]
    final_b_eggs = b_eggs[-1]

    # We'll scale egg diff into [-1, 1] using a rough max of 30 eggs difference
    def normalize_value(my_final_eggs, opp_final_eggs):
        diff = my_final_eggs - opp_final_eggs
        return max(-1.0, min(1.0, diff / 30.0))

    samples = []

    for t in range(turn_count):
        turn_frac = t / max(1, (turn_count - 1))

        # Common normalized trapdoor features
        (td1x, td1y), (td2x, td2y) = trapdoors
        td1x_n = td1x / 7.0
        td1y_n = td1y / 7.0
        td2x_n = td2x / 7.0
        td2y_n = td2y / 7.0

        # 0 if not triggered, 1 if triggered on this move
        trap_trig = float(trapdoor_triggered[t])

        # Is this A or B's move?
        if t % 2 == 0:
            # A just moved
            my_eg = a_eggs[t]
            op_eg = b_eggs[t]
            my_td = a_turds[t]
            op_td = b_turds[t]
            my_tm = a_time[t]
            op_tm = b_time[t]
            my_mv = a_moves_left[t]
            op_mv = b_moves_left[t]
            my_pos = pos[t]
            my_spawn = spawn_a
            op_spawn = spawn_b

            target = normalize_value(final_a_eggs, final_b_eggs)
        else:
            # B just moved
            my_eg = b_eggs[t]
            op_eg = a_eggs[t]
            my_td = b_turds[t]
            op_td = a_turds[t]
            my_tm = b_time[t]
            op_tm = a_time[t]
            my_mv = b_moves_left[t]
            op_mv = a_moves_left[t]
            my_pos = pos[t]
            my_spawn = spawn_b
            op_spawn = spawn_a

            target = normalize_value(final_b_eggs, final_a_eggs)

        myx, myy = my_pos
        msx, msy = my_spawn
        osx, osy = op_spawn

        # Normalize coords by 7 (board indices [0..7])
        myx_n = myx / 7.0
        myy_n = myy / 7.0
        msx_n = msx / 7.0
        msy_n = msy / 7.0
        osx_n = osx / 7.0
        osy_n = osy / 7.0

        # Normalize times by start_time
        my_tm_n = my_tm / start_time
        op_tm_n = op_tm / start_time

        # Normalize eggs, turds, moves roughly
        my_eg_n = my_eg / 30.0
        op_eg_n = op_eg / 30.0
        egg_diff_n = (my_eg - op_eg) / 30.0

        my_td_n = my_td / 5.0
        op_td_n = op_td / 5.0

        my_mv_n = my_mv / 40.0
        op_mv_n = op_mv / 40.0

        features = [
            myx_n, myy_n,
            msx_n, msy_n,
            osx_n, osy_n,
            td1x_n, td1y_n,
            td2x_n, td2y_n,
            my_eg_n, op_eg_n, egg_diff_n,
            my_td_n, op_td_n,
            my_tm_n, op_tm_n,
            my_mv_n, op_mv_n,
            trap_trig,
            turn_frac,
        ]

        samples.append((features, target))

    return samples


class ChickenValueDataset(Dataset):
    def __init__(self, csv_path: str):
        df = pd.read_csv(csv_path)
        self.samples = []

        for idx, row in df.iterrows():
            try:
                row_samples = build_samples_from_row(row)
                self.samples.extend(row_samples)
            except Exception as e:
                # Skip bad rows but log if needed
                print(f"Skipping row {idx} due to error: {e}")

        print(f"Built dataset with {len(self.samples)} state samples.")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        feats, target = self.samples[idx]
        x = torch.tensor(feats, dtype=torch.float32)
        y = torch.tensor(target, dtype=torch.float32)
        return x, y


# -----------------------------
# 2. The Value Network
# -----------------------------

class ValueNet(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Tanh(),  # output in [-1, 1]
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


# -----------------------------
# 3. Training loop
# -----------------------------

def train():
    dataset = ChickenValueDataset(CSV_PATH)
    input_dim = len(dataset[0][0])

    model = ValueNet(input_dim=input_dim, hidden_dim=128).to(DEVICE)

    # Simple train/val split
    n = len(dataset)
    split = int(0.9 * n)
    train_ds, val_ds = torch.utils.data.random_split(dataset, [split, n - split])

    train_loader = DataLoader(train_ds, batch_size=512, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=1024, shuffle=False)

    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.MSELoss()

    epochs = 10

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        for xb, yb in train_loader:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)

            optimizer.zero_grad()
            preds = model(xb)
            loss = criterion(preds, yb)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * xb.size(0)

        avg_train = total_loss / len(train_ds)

        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE)
                preds = model(xb)
                loss = criterion(preds, yb)
                val_loss += loss.item() * xb.size(0)
        avg_val = val_loss / len(val_ds)

        print(f"Epoch {epoch:02d} | train MSE={avg_train:.4f} | val MSE={avg_val:.4f}")

    # Save model
    out_path = Path("value_net.pt")
    torch.save(model.state_dict(), out_path)
    print(f"Saved trained value net to {out_path.absolute()}")


if __name__ == "__main__":
    train()
