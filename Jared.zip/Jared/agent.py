from collections.abc import Callable
from time import time
from typing import List, Tuple
import math
import numpy as np

from game import *
from game.enums import Direction, MoveType

from .trapdoor_belief import TrapdoorBelief



class TimeoutError(Exception):
    """Raised when our per-move time budget is exceeded during search."""
    pass


class PlayerAgent:
    """
    /you may add functions, however, __init__ and play are the entry points for
    your program and should not be changed.
    """

    def __init__(self, board: board.Board, time_left: Callable):
        # Keep __init__ light; initialize persistent state lazily in play().
        pass

    # ----------------------------------------------------------------------
    # Main entry point
    # ----------------------------------------------------------------------
    def play(
        self,
        board: board.Board,
        sensor_data: List[Tuple[bool, bool]],
        time_left: Callable,
    ):
        # Lazily create trapdoor belief tracker
        if not hasattr(self, "tracker"):
            map_size = board.game_map.MAP_SIZE
            self.tracker = TrapdoorBelief(map_size=map_size)

        # Identify our parity (even / odd) once.
        if not hasattr(self, "my_parity"):
            self.my_parity = board.chicken_player.even_chicken

        # 1. Update trapdoor beliefs using our current location + sensor data
        current_loc = board.chicken_player.get_location()
        self.tracker.update(current_loc, sensor_data)

        # 2. Time budget for this move
        turns_remaining = board.turns_left_player
        my_time_remaining = time_left()
        if turns_remaining > 0:
            time_budget = (my_time_remaining / turns_remaining) - 0.05
        else:
            time_budget = my_time_remaining / 10.0
        time_budget = min(max(time_budget, 0.05), 9.0)

        start_time = time()

        moves = board.get_valid_moves()
        if not moves:
            # No valid moves; engine will handle the game-end penalty,
            # we just need to return something syntactically valid.
            return (Direction.UP, MoveType.PLAIN)
        best_move = moves[0]

        # 3. Iterative deepening negamax with alpha–beta pruning
        current_depth = 1
        max_depth = 12

        while True:
            try:
                score, move = self.negamax(
                    board,
                    depth=current_depth,
                    alpha=-math.inf,
                    beta=math.inf,
                    start_time=start_time,
                    time_budget=time_budget,
                )

                if move is not None:
                    best_move = move

                current_depth += 1
                # Stop if depth too big or we've spent a decent chunk of our budget
                if current_depth > max_depth or (time() - start_time) > (time_budget * 0.6):
                    break

            except TimeoutError:
                # Out of time for this move; return best move from previous depth
                break

        return best_move

    # ----------------------------------------------------------------------
    # Heuristic evaluation
    # ----------------------------------------------------------------------
    def heuristic(self, board: board.Board) -> float:
        """
        Evaluate a position from OUR perspective.
        Positive is good for us, negative is good for the opponent.
        """

        # 1. Egg lead (including corner bonuses, which engine’s egg count already includes)
        my_eggs = board.chicken_player.get_eggs_laid()
        op_eggs = board.chicken_enemy.get_eggs_laid()
        score = (my_eggs - op_eggs) * 100.0

        # 2. Mobility (our moves - their moves)
        my_moves = len(board.get_valid_moves())
        op_moves = len(board.get_valid_moves(enemy=True))
        score += (my_moves - op_moves) * 15.0

        # 3. Turd advantage (how many we have left vs them)
        my_turds = board.chicken_player.get_turds_left()
        op_turds = board.chicken_enemy.get_turds_left()
        score += (my_turds - op_turds) * 10.0

        # Strong penalty for being nearly or completely stuck
        if my_moves == 0:
            score -= 10000.0
        elif my_moves == 1:
            score -= 150.0

        # 4. Positional features
        current_loc = board.chicken_player.get_location()
        map_size = board.game_map.MAP_SIZE
        x, y = current_loc

        # Distance to nearest edge – slight preference for not being deep in the center
        dist_to_edge = min(x, map_size - 1 - x, y, map_size - 1 - y)
        score -= dist_to_edge * 15.0

        # Corners: treat same-parity corners as "our" corners, opposite as enemy corners
        corners = [
            (0, 0),
            (0, map_size - 1),
            (map_size - 1, 0),
            (map_size - 1, map_size - 1),
        ]
        for cx, cy in corners:
            corner_parity = (cx + cy) % 2

            # Our corners (3-egg potential)
            if corner_parity == self.my_parity:
                if (x, y) == (cx, cy):
                    score += 40.0
            else:
                # Enemy corners: we like blocking or standing on them
                if hasattr(board, "turds_player") and (cx, cy) in board.turds_player:
                    score += 250.0
                elif (x, y) == (cx, cy):
                    score += 50.0

        # Encourage exploration of fresh squares
        if hasattr(board, "eggs_player") and hasattr(board, "turds_player"):
            if current_loc not in board.eggs_player and current_loc not in board.turds_player:
                score += 10.0

        # 5. Distance to opponent – closer can be good for applying pressure
        opp_loc = board.chicken_enemy.get_location()
        dist_to_opp = self.manhattan(current_loc, opp_loc)
        score += max(0, 8 - dist_to_opp) * 3.0

        # 6. Trapdoor risk using our belief tracker
        if dist_to_edge == 0:
            risk = 0.0  # edges can’t have trapdoors
        else:
            risk = self.tracker.get_risk(current_loc)
        score -= risk * 2000.0

        # Extra huge penalty if we *know* this is a trapdoor square
        if hasattr(board, "found_trapdoors") and current_loc in board.found_trapdoors:
            score -= 10000.0

        return score

    # ----------------------------------------------------------------------
    # Negamax + alpha–beta pruning
    # ----------------------------------------------------------------------
    def negamax(
        self,
        board: board.Board,
        depth: int,
        alpha: float,
        beta: float,
        start_time: float,
        time_budget: float,
    ):
        """
        Negamax search with alpha–beta pruning.

        Returns:
            (score, best_move) where best_move is (Direction, MoveType) or None.
        """
        # Time check
        if (time() - start_time) > time_budget:
            raise TimeoutError()

        # Leaf or game over → evaluate
        if depth == 0 or board.is_game_over():
            return self.heuristic(board), None

        moves = board.get_valid_moves()
        if not moves:
            # No moves for us is extremely bad (they get 5 eggs)
            return -10000.0, None

        best_score = -math.inf
        best_move = moves[0]

        # Basic move ordering: Egg > Turd > Plain
        def move_priority(m):
            m_type = m[1]
            if m_type == MoveType.EGG:
                return 3
            if m_type == MoveType.TURD:
                return 2
            return 1

        moves.sort(key=move_priority, reverse=True)

        for move in moves:
            dir_enum, type_enum = move

            # Forecast our move
            next_board = board.forecast_move(dir_enum, type_enum)
            if next_board is None:
                continue

            # Switch perspective: now the other chicken is "player"
            next_board.reverse_perspective()

            score, _ = self.negamax(
                next_board, depth - 1, -beta, -alpha, start_time, time_budget
            )
            score = -score  # negamax sign flip

            if score > best_score:
                best_score = score
                best_move = move

            alpha = max(alpha, score)
            if alpha >= beta:
                break  # alpha–beta cut-off

        return best_score, best_move

    # ----------------------------------------------------------------------
    # Utility
    # ----------------------------------------------------------------------
    @staticmethod
    def manhattan(a: Tuple[int, int], b: Tuple[int, int]) -> int:
        return abs(a[0] - b[0]) + abs(a[1] - b[1])
